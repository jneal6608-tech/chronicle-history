"""Central configuration. Every value has a sensible default; override any of
them in the `.env` file next to this folder (copy `.env.example`)."""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP_DIR = ROOT / "app"


def _load_env_file() -> None:
    env = ROOT / ".env"
    if not env.exists():
        return
    for line in env.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = line.split("=", 1)
        key, val = key.strip(), val.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = val


_load_env_file()


def _get(name: str, default: str) -> str:
    return os.environ.get(name, default).strip() or default


def _float(name: str, default: float) -> float:
    try:
        return float(_get(name, str(default)))
    except ValueError:
        return default


# --- Platform ---------------------------------------------------------------
# ChromeOS runs Linux apps in a container ("penguin"). Chrome reaches it at
# http://penguin.linux.test:<port> (or http://localhost:<port> via ChromeOS port
# forwarding). The container is only reachable from this Chromebook itself.
IS_CHROMEOS = (Path("/opt/google/cros-containers").exists()
               or Path("/dev/.cros_milestone").exists()
               or os.environ.get("CH_FORCE_CHROMEOS") == "1")

# --- Server -----------------------------------------------------------------
HOST = _get("CH_HOST", "0.0.0.0" if IS_CHROMEOS else "127.0.0.1")
PORT = int(_get("CH_PORT", "8765"))
DATA_DIR = Path(_get("CH_DATA_DIR", str(ROOT / "data"))).resolve()
JOBS_DIR = DATA_DIR / "jobs"
MAX_UPLOAD_GB = _float("CH_MAX_UPLOAD_GB", 12.0)
MAX_SOURCE_MINUTES = _float("CH_MAX_SOURCE_MINUTES", 180.0)

# --- Branding ---------------------------------------------------------------
CHANNEL_NAME = _get("CH_CHANNEL_NAME", "Chronicle History")
CHANNEL_HASHTAG = _get("CH_CHANNEL_HASHTAG", "#ChronicleHistory")
SHOW_CHANNEL_TAG = _get("CH_SHOW_CHANNEL_TAG", "1") == "1"

# --- Speech to text (faster-whisper, free, runs locally) ---------------------
# tiny / base / small / medium / large-v3, or a path to a local model folder.
WHISPER_MODEL = _get("CH_WHISPER_MODEL", "base")  # Chromebook-friendly default
WHISPER_LANGUAGE = _get("CH_WHISPER_LANGUAGE", "en")  # "auto" to detect
WHISPER_DEVICE = _get("CH_WHISPER_DEVICE", "auto")     # auto / cpu / cuda

# --- AI analysis (Claude). Optional: without a key the free offline analyser runs.
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "").strip()
CLAUDE_MODEL = _get("CH_CLAUDE_MODEL", "claude-opus-5-5")
CLAUDE_EFFORT = _get("CH_CLAUDE_EFFORT", "medium")
ANALYSIS_MODE = _get("CH_ANALYSIS_MODE", "auto")  # auto / claude / offline

# --- Rendering ----------------------------------------------------------------
OUT_W, OUT_H = 1080, 1920
X264_PRESET = _get("CH_X264_PRESET", "veryfast")  # "medium" = slightly smaller files, ~3x slower
X264_CRF = _get("CH_X264_CRF", "18")
TARGET_LUFS = _get("CH_TARGET_LUFS", "-14")
MIN_SPEED, MAX_SPEED = 1.05, 1.15

# Target length of a finished short (seconds, after speed-up).
TARGET_MIN_S, TARGET_MAX_S = 60.0, 90.0
ABS_MIN_S = 25.0          # never output a short below this
MIN_CLIPS, MAX_CLIPS = 3, 5

FONTS_DIR = APP_DIR / "assets" / "fonts"
CAPTION_FONT = "Montserrat ExtraBold"
STATIC_DIR = APP_DIR / "static"

JOBS_DIR.mkdir(parents=True, exist_ok=True)


def studio_urls() -> list[str]:
    """Addresses to open in Chrome, best first."""
    if IS_CHROMEOS or HOST == "0.0.0.0":
        return [f"http://penguin.linux.test:{PORT}", f"http://localhost:{PORT}"]
    return [f"http://{HOST}:{PORT}"]
