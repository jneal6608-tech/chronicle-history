"""Finds the 3-5 best standalone stories in a documentary.

Two engines share the same validation step:
  * Claude (recommended) - reads the whole timestamped transcript plus visual
    pacing data, ranks candidate stories and writes titles/descriptions.
  * Offline - a free, deterministic storytelling scorer that runs with no API key.

Both engines may only choose ranges of *existing sentences*; the clip
boundaries always land on real sentence edges in the narration, so nothing
is fabricated or cut mid-thought.
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from typing import Callable, Optional

from . import config
from .media import fmt_ts

# Source-time limits for a segment (output is shorter after speed-up + pause removal).
SRC_MIN = 28.0
SRC_IDEAL_MIN = 62.0
SRC_IDEAL_MAX = 100.0
SRC_MAX = 104.0

# --------------------------------------------------------------------------- sentences

_END_RE = re.compile(r"[.!?…][\"')\]]*$")


def build_sentences(words: list[dict]) -> list[dict]:
    sents, cur = [], []
    for k, w in enumerate(words):
        cur.append(k)
        nxt = words[k + 1] if k + 1 < len(words) else None
        gap = (nxt["s"] - w["e"]) if nxt else 99
        ends = bool(_END_RE.search(w["w"]))
        too_long = len(cur) >= 45 and (w["w"].endswith(",") or len(cur) >= 60)
        if ends or gap > 1.6 or too_long or nxt is None:
            sents.append(cur)
            cur = []
    out = []
    for i, idxs in enumerate(sents):
        ws = [words[k] for k in idxs]
        out.append({"i": i, "s": ws[0]["s"], "e": ws[-1]["e"], "w0": idxs[0], "w1": idxs[-1],
                    "text": " ".join(x["w"] for x in ws).strip()})
    return out


# --------------------------------------------------------------------------- lexicons

DRAMA = set("""war wars battle battles empire empires emperor king kings queen pharaoh sultan tsar czar
death died dead dying killed kill killing murdered murder assassinated assassination executed execution
betrayed betrayal traitor collapse collapsed fell fall fallen ruin ruins destroyed destruction burned burning
revolution revolt rebellion rebels uprising conquered conquest invaded invasion siege besieged massacre
plague famine disaster catastrophe secret secrets mystery mysterious hidden lost discovered discovery
treasure gold fortune legend legendary curse cursed scandal coup throne crown dynasty army armies soldiers
navy fleet weapon weapons bomb bombs nuclear victory defeat defeated surrender escape escaped prison
poison poisoned spy spies conspiracy enemy enemies blood bloody brutal tragedy tragic terror fear
shocking strange bizarre unbelievable incredible extraordinary forbidden vanished disappeared""".split())

SUPERLATIVE = set("""first last largest biggest greatest deadliest richest oldest most least only never nobody
worst best longest fastest strongest tallest smallest youngest""".split())

HOOK_PHRASES = ["imagine", "what if", "few people know", "nobody knows", "no one knows", "the truth",
                "but here's", "here's the thing", "believe it or not", "in the year", "it was the",
                "have you ever", "why did", "how did", "what happened", "this is the story", "the story of",
                "one of the", "the most", "was the first", "was the last"]

ENDING_PHRASES = ["to this day", "ever since", "forever", "would never", "never again", "and that is why",
                  "that's why", "and so", "the end of", "finally", "in the end", "legacy", "changed history",
                  "changed the world", "remains", "still", "would go on", "became"]

DANGLING = {"he", "she", "they", "it", "this", "that", "these", "those", "his", "her", "their", "its",
            "and", "but", "so", "then", "also", "which", "however", "meanwhile", "him", "them", "there"}

PROMO = ["subscribe", "patreon", "sponsor", "sponsored", "thanks for watching", "thank you for watching",
         "like and", "comment below", "next video", "this video", "link in the description", "welcome back",
         "welcome to", "notification bell", "members of the channel", "see you next", "in today's video"]

STOP = set("""The A An And But So Then He She They It This That These Those His Her Their In On At Of For
To With By From As When While After Before During If Or Nor Yet Its We You I Our Your One Two Three Four
Five Six Seven Eight Nine Ten Yes No Today Now Here There What Why How Who Where Which Even Still Just
Mr Mrs Sir Lord Lady Saint St Not Over Under Into Some Many Most Every Each All""".split())

_NUM = re.compile(r"\b(\d{2,4}|\d+(?:[.,]\d+)?\s?(?:%|percent|million|billion|thousand)|hundreds|thousands|millions)\b", re.I)


def _tokens(text: str) -> list[str]:
    return re.findall(r"[A-Za-z']+", text.lower())


def proper_nouns(sents: list[dict]) -> list[str]:
    names = []
    for s in sents:
        toks = re.findall(r"[A-Za-z][A-Za-z'\-]+", s["text"])
        for k, t in enumerate(toks):
            if k == 0 or not t[0].isupper() or t in STOP or len(t) < 3:
                continue
            names.append(t.strip("'"))
    return names


# --------------------------------------------------------------------------- features

def _hook_score(text: str) -> tuple[float, list[str]]:
    low = text.lower()
    toks = _tokens(text)
    score, why = 0.0, []
    if not toks:
        return -1.0, ["empty"]
    if toks[0] in DANGLING:
        score -= 0.9 if toks[0] in {"he", "she", "they", "it", "him", "them", "its", "his", "her", "their"} else 0.5
        why.append(f"opens with '{toks[0]}' (needs context)")
    if text.rstrip().endswith("?"):
        score += 0.7
        why.append("opens with a question")
    hp = [p for p in HOOK_PHRASES if p in low]
    if hp:
        score += 0.5
        why.append(f"hook phrase \"{hp[0]}\"")
    if _NUM.search(text):
        score += 0.35
        why.append("opens on a concrete date/number")
    sup = [t for t in toks if t in SUPERLATIVE]
    if sup:
        score += 0.3
        why.append(f"superlative \"{sup[0]}\"")
    dr = [t for t in toks if t in DRAMA]
    if dr:
        score += min(0.5, 0.2 * len(dr))
        why.append("dramatic opening (" + ", ".join(dict.fromkeys(dr[:3])) + ")")
    if len(toks) < 4:
        score -= 0.3
    return score, why


def _end_score(text: str) -> tuple[float, list[str]]:
    low = text.lower()
    score, why = 0.0, []
    t = text.rstrip()
    if t.endswith("?"):
        score -= 0.6
        why.append("ends on an open question")
    elif t.endswith((".", "!", "…")):
        score += 0.3
    if t.endswith((":", ",")):
        score -= 0.8
    ep = [p for p in ENDING_PHRASES if p in low]
    if ep:
        score += 0.6
        why.append(f"conclusive ending (\"{ep[0]}\")")
    if len(_tokens(text)) <= 3:
        score -= 0.3
    return score, why


def _dur_fit(d: float) -> float:
    if SRC_IDEAL_MIN <= d <= SRC_IDEAL_MAX:
        return 1.0
    if d < SRC_IDEAL_MIN:
        return max(0.0, (d - SRC_MIN) / (SRC_IDEAL_MIN - SRC_MIN)) * 0.75
    return max(0.0, 1 - (d - SRC_IDEAL_MAX) / (SRC_MAX - SRC_IDEAL_MAX))


def _scene_rate(scenes: list[float], s: float, e: float) -> float:
    n = sum(1 for t in scenes if s <= t <= e)
    return n / max((e - s) / 60, 0.1)


_CONTENT_STOP = set("""about after again against also because been before being between both could does doing
down during each from further have having here into itself just more most much must only other over same
should some such than that their them then there these they this those through under until very were what
when where which while will with would your said like even ever still every many first""".split())


def _content_words(text: str) -> Counter:
    return Counter(t for t in _tokens(text) if len(t) > 3 and t not in _CONTENT_STOP)


def _cos(a: Counter, b: Counter) -> float:
    if not a or not b:
        return 0.0
    num = sum(a[k] * b[k] for k in a.keys() & b.keys())
    return num / (math.sqrt(sum(v * v for v in a.values())) * math.sqrt(sum(v * v for v in b.values())))


def boundary_strengths(sents: list[dict], scenes: list[float]) -> list[float]:
    """b[k] = how strongly a new story/section starts at sentence k (0..1).

    Combines a pause in the narration, a visual cut at the same moment, and a
    shift in vocabulary between the sentences before and after (TextTiling-style).
    b[0] and b[n] are 1 (start and end of the film)."""
    n = len(sents)
    bag = [_content_words(s["text"]) for s in sents]
    b = [1.0] * (n + 1)
    for k in range(1, n):
        left = sum((bag[x] for x in range(max(0, k - 3), k)), Counter())
        right = sum((bag[x] for x in range(k, min(n, k + 3))), Counter())
        shift = 1.0 - _cos(left, right)
        gap = sents[k]["s"] - sents[k - 1]["e"]
        g = min(1.0, max(0.0, (gap - 0.3) / 1.5))
        cut = 1.0 if any(sents[k - 1]["e"] - 0.6 <= t <= sents[k]["s"] + 0.6 for t in scenes) else 0.0
        b[k] = round(0.45 * g + 0.25 * cut + 0.30 * shift, 3)
    return b


def score_window(sents, i, j, scenes, avg_scene_rate, total_dur, bounds=None) -> dict:
    s, e = sents[i]["s"], sents[j]["e"]
    text = " ".join(x["text"] for x in sents[i:j + 1])
    toks = _tokens(text)
    nw = max(len(toks), 1)
    hook, hook_why = _hook_score(sents[i]["text"])
    # Strongest hook in the first two sentences counts (titles often come second).
    if j > i:
        h2, w2 = _hook_score(sents[i + 1]["text"])
        if h2 * 0.6 > hook and hook > -0.4:
            hook, hook_why = h2 * 0.6, w2
    end, end_why = _end_score(sents[j]["text"])
    drama_hits = [t for t in toks if t in DRAMA]
    drama = min(1.0, len(drama_hits) / nw * 100 / 6)
    facts = min(1.0, len(_NUM.findall(text)) / nw * 100 / 3)
    names = proper_nouns(sents[i:j + 1])
    name_d = min(1.0, len(names) / nw * 100 / 6)
    pacing = min(1.0, _scene_rate(scenes, s, e) / max(avg_scene_rate, 0.5)) if scenes else 0.5
    low = text.lower()
    promo = sum(1 for p in PROMO if p in low)
    if bounds is None:
        bounds = [1.0] * (len(sents) + 1)
    edge_in, edge_out = bounds[i], bounds[j + 1]
    boundary = (edge_in + edge_out) / 2
    # A window must not swallow a section break stronger than its own edges:
    # that would glue two stories together or cut one in half.
    internal = max(bounds[i + 1:j + 1], default=0.0)
    crossing = max(0.0, internal - min(edge_in, edge_out))
    durfit = _dur_fit(e - s)
    score = (1.2 * hook + 1.0 * end + 1.0 * drama + 0.5 * facts + 0.35 * name_d +
             0.3 * pacing + 1.1 * durfit + 1.2 * boundary - 2.5 * crossing - 1.5 * promo)
    if s < 15:
        score -= 0.4  # cold opens usually tease the whole video, not one story
    return {"i": i, "j": j, "start": s, "end": e, "score": round(score, 3), "names": names,
            "drama_words": list(dict.fromkeys(drama_hits))[:6],
            "parts": {"hook": round(hook, 2), "ending": round(end, 2), "drama": round(drama, 2),
                      "facts": round(facts, 2), "names": round(name_d, 2), "pacing": round(pacing, 2),
                      "duration_fit": round(durfit, 2), "boundary": round(boundary, 2),
                      "crosses_section": round(crossing, 2), "promo": promo},
            "hook_why": hook_why, "end_why": end_why}


def target_clip_count(duration: float) -> int:
    if duration < 8 * 60:
        return 3
    if duration < 20 * 60:
        return 4
    return 5


def _overlap(a, b) -> float:
    inter = max(0.0, min(a["end"], b["end"]) - max(a["start"], b["start"]))
    return inter / max(1e-6, min(a["end"] - a["start"], b["end"] - b["start"]))


def _same_story(a_names, b_names) -> bool:
    A = {n for n, c in Counter(a_names).most_common(4)}
    B = {n for n, c in Counter(b_names).most_common(4)}
    if len(A) < 2 or len(B) < 2:
        return False
    return len(A & B) / len(A | B) >= 0.6


# --------------------------------------------------------------------------- offline engine

def _title_from(sents, i, j) -> str:
    best, best_s = sents[i]["text"], -9.0
    for k in range(i, min(j + 1, i + 6)):
        sc, _ = _hook_score(sents[k]["text"])
        sc -= 0.1 * (k - i)
        if sc > best_s:
            best, best_s = sents[k]["text"], sc
    t = best.strip()
    if len(t) > 70:
        cut = max(t.rfind(",", 0, 70), t.rfind(" - ", 0, 70), t.rfind(";", 0, 70))
        t = t[:cut] if cut > 25 else t[:67].rsplit(" ", 1)[0] + "…"
    return t.rstrip(",;:- ")


_GENERIC_NAMES = set("""western eastern northern southern major minor christian christians catholic catholics
protestant protestants empire roman romans egyptian egyptians greek greeks army navy king queen emperor
general captain lord great old new first second third last day days year years century bc ad""".split())


def name_phrases(sents: list[dict]) -> Counter:
    """Capitalised name phrases ("Golden Horn", "Constantinople"), skipping sentence-initial words."""
    found: Counter = Counter()
    for s in sents:
        toks = re.findall(r"[A-Za-z][A-Za-z'\-]*|[.,;:!?]", s["text"])
        cur: list[str] = []
        for k, t in enumerate(toks + ["."]):
            cap = t[:1].isupper() and t not in STOP and (k > 0 or (k + 1 < len(toks) and toks[k + 1][:1].isupper()))
            if cap:
                cur.append(t)
                continue
            if cur:
                words = cur if len(cur) > 1 else [w for w in cur if w.lower() not in _GENERIC_NAMES]
                if words and not (len(words) == 1 and len(words[0]) < 4):
                    found[" ".join(words)] += 1
                cur = []
    return found


def _era_tag(text: str) -> str | None:
    if re.search(r"\b\d+\s?(BC|BCE)\b", text, re.I):
        return "#ancienthistory"
    years = [int(y) for y in re.findall(r"\b(1[0-9]{3}|[5-9][0-9]{2})\b", text)]
    if not years:
        return None
    y = years[0]
    return ("#medievalhistory" if y < 1500 else "#earlymodernhistory" if y < 1800
            else "#19thcentury" if y < 1900 else "#20thcentury" if y < 2000 else None)


def _hashtags(names: list[str], drama: list[str], phrases: Counter | None = None, text: str = "") -> list[str]:
    tags = ["#history", "#shorts", config.CHANNEL_HASHTAG]
    ranked = sorted((phrases or Counter(names)).items(), key=lambda kv: (-kv[1], -len(kv[0])))
    for n, _ in ranked[:3]:
        tag = "#" + re.sub(r"[^A-Za-z0-9]", "", n)
        if len(tag) > 3 and tag.lower() not in {t.lower() for t in tags}:
            tags.append(tag)
    era = _era_tag(text)
    if era:
        tags.append(era)
    themed = {"war": "#militaryhistory", "battle": "#militaryhistory", "siege": "#militaryhistory",
              "pharaoh": "#ancientegypt", "king": "#royalhistory",
              "queen": "#royalhistory", "mystery": "#historymystery", "secret": "#historyfacts",
              "discovered": "#historyfacts", "revolution": "#revolution", "plague": "#medievalhistory"}
    for d in drama:
        if d in themed and themed[d] not in tags:
            tags.append(themed[d])
    tags.append("#historyfacts" if "#historyfacts" not in tags else "#didyouknow")
    return tags[:9]


def _explain(c) -> str:
    p = c["parts"]
    bits = []
    if c["hook_why"]:
        bits.append("Strong opening: " + "; ".join(c["hook_why"][:2]))
    if p["drama"] >= 0.4 and c["drama_words"]:
        bits.append("dense with dramatic events (" + ", ".join(c["drama_words"][:4]) + ")")
    if p["facts"] >= 0.4:
        bits.append("rich in concrete dates and numbers")
    if c["end_why"]:
        bits.append("ends cleanly: " + c["end_why"][0])
    elif p["ending"] > 0:
        bits.append("ends on a complete sentence")
    if p["boundary"] >= 0.5:
        bits.append("starts and ends exactly where this story begins and ends in the documentary")
    if p["pacing"] >= 0.8:
        bits.append("visually busy section with frequent scene changes")
    bits.append(f"{c['end']-c['start']:.0f}s self-contained segment")
    s = "; ".join(bits)
    return s[0].upper() + s[1:] + "."


def _pct(score: float, ranked: list[dict]) -> int:
    """Show offline scores on a 0-100 scale relative to the best story found."""
    hi = max(c["score"] for c in ranked)
    lo = min(0.0, min(c["score"] for c in ranked))
    return int(round(40 + 58 * (score - lo) / max(1e-6, hi - lo)))


def offline_select(sents, scenes, total_dur, progress=None) -> dict:
    avg_rate = len(scenes) / max(total_dur / 60, 1) if scenes else 0
    bounds = boundary_strengths(sents, scenes)
    cands = []
    for i in range(len(sents)):
        for j in range(i, len(sents)):
            d = sents[j]["e"] - sents[i]["s"]
            if d > SRC_MAX:
                break
            if d < SRC_MIN:
                continue
            cands.append(score_window(sents, i, j, scenes, avg_rate, total_dur, bounds))
        if progress and i % 25 == 0:
            progress(i / max(len(sents), 1))
    cands.sort(key=lambda c: -c["score"])
    want = target_clip_count(total_dur)
    chosen: list[dict] = []
    ranked: list[dict] = []
    for c in cands:
        if any(_overlap(c, x) > 0 for x in ranked):
            continue
        if any(_same_story(c["names"], x["names"]) for x in ranked):
            continue
        ranked.append(c)
        if len(ranked) >= 10:
            break
    if not ranked:
        return {"candidates": [], "clips": []}
    best = ranked[0]["score"]
    for c in ranked:
        if len(chosen) >= want:
            break
        if len(chosen) >= config.MIN_CLIPS and c["score"] < 0.55 * best:
            break
        chosen.append(c)
    clips, cand_out = [], []
    for rank, c in enumerate(ranked):
        sel = c in chosen
        title = _title_from(sents, c["i"], c["j"])
        entry = {"rank": rank + 1, "start_sentence": c["i"], "end_sentence": c["j"],
                 "start": c["start"], "end": c["end"], "title": title,
                 "score": _pct(c["score"], ranked),
                 "selected": sel, "summary": _explain(c), "parts": c["parts"]}
        cand_out.append(entry)
        if sel:
            first = sents[c["i"]]["text"]
            second = sents[c["i"] + 1]["text"] if c["j"] > c["i"] else ""
            desc = (first + " " + second).strip()
            if len(desc) > 220:
                desc = desc[:217].rsplit(" ", 1)[0] + "…"
            tags = _hashtags(c["names"], c["drama_words"], name_phrases(sents[c["i"]:c["j"] + 1]),
                             " ".join(x["text"] for x in sents[c["i"]:c["j"] + 1]))
            kw = [n for n, _ in Counter(c["names"]).most_common(6)] + c["drama_words"][:4]
            clips.append({"start_sentence": c["i"], "end_sentence": c["j"], "title": title,
                          "description": f"{desc}\n\nFull documentary on {config.CHANNEL_NAME}.",
                          "hashtags": tags, "why_selected": _explain(c), "keywords": kw,
                          "scores": c["parts"], "rank": rank + 1})
    clips.sort(key=lambda x: x["start_sentence"])
    return {"candidates": cand_out, "clips": clips}


# --------------------------------------------------------------------------- Claude engine

_SCHEMA = {
    "type": "object",
    "properties": {
        "documentary_summary": {"type": "string"},
        "candidates": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "start_sentence": {"type": "integer"},
                    "end_sentence": {"type": "integer"},
                    "working_title": {"type": "string"},
                    "storytelling": {"type": "integer"},
                    "historical_significance": {"type": "integer"},
                    "curiosity": {"type": "integer"},
                    "pacing": {"type": "integer"},
                    "standalone_value": {"type": "integer"},
                    "overall": {"type": "integer"},
                    "assessment": {"type": "string"},
                },
                "required": ["start_sentence", "end_sentence", "working_title", "storytelling",
                             "historical_significance", "curiosity", "pacing", "standalone_value",
                             "overall", "assessment"],
                "additionalProperties": False,
            },
        },
        "selected": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "candidate_index": {"type": "integer"},
                    "title": {"type": "string"},
                    "description": {"type": "string"},
                    "hashtags": {"type": "array", "items": {"type": "string"}},
                    "why_selected": {"type": "string"},
                    "highlight_words": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["candidate_index", "title", "description", "hashtags",
                             "why_selected", "highlight_words"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["documentary_summary", "candidates", "selected"],
    "additionalProperties": False,
}

_SYSTEM = f"""You are the short-form editor for {config.CHANNEL_NAME}, a history animation YouTube channel.
You receive the complete timestamped narration of one finished long-form documentary, split into
numbered sentences, plus a per-minute visual-pacing signal (scene changes per minute).

Your job: find the stories in this documentary that would make the best standalone YouTube Shorts /
TikToks / Reels, then pick the final set.

Each short is a contiguous range of sentences [start_sentence, end_sentence] (inclusive), used exactly as
narrated - you cannot reorder, rewrite or add narration.

A great short:
- opens with a compelling first sentence that makes sense to a viewer who has seen nothing else
  (no dangling "he"/"this"/"but" that refers to something earlier, unless it is obvious from the sentence);
- tells one complete historical idea or story: a revelation, dramatic event, unexpected fact,
  turning point or curiosity-driven story;
- ends on a satisfying, conclusive sentence (a payoff or resolution, not a cliffhanger into the next chapter);
- runs {SRC_IDEAL_MIN:.0f}-{SRC_IDEAL_MAX:.0f} seconds of source narration (it will be sped up ~1.1x to land at 60-90s).
  Shorter (down to {SRC_MIN:.0f}s) is acceptable only when the story is genuinely complete and strong. Never exceed {SRC_MAX:.0f}s.
Avoid: channel intros/outros, sponsor reads, calls to subscribe, recaps, and sections that only make sense
in context. Selected shorts must not overlap and must not tell the same story twice.

Process: read the whole transcript first. Then list 6-10 candidate segments drawn from across the entire
documentary (not just the beginning), each scored 0-10 on storytelling, historical_significance, curiosity,
pacing and standalone_value, with an overall 0-100 and a one-sentence assessment. Then select the best
{config.MIN_CLIPS}-{config.MAX_CLIPS} candidates (by candidate_index into your list) - choose fewer only if the extra ones would be weak.

For each selected short write:
- title: a scroll-stopping title, max 70 characters, no clickbait that the clip does not pay off;
- description: 1-3 sentences for the post caption;
- hashtags: 5-9 hashtags including #history #shorts {config.CHANNEL_HASHTAG};
- why_selected: 1-2 sentences explaining why this works as a standalone short;
- highlight_words: 4-12 important words that appear verbatim in that segment's narration
  (names, places, dates, numbers, key nouns) to colour in the captions.

Strict accuracy rule: titles, descriptions and hashtags must only state facts that the narration in that
segment actually says. Do not add outside facts, dates, or claims. If unsure, stay general."""


def claude_select(sents, scenes, total_dur, title_hint: str, progress=None) -> dict:
    import anthropic

    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY or None, max_retries=3)
    lines = [f"[{s['i']}] ({fmt_ts(s['s'])}-{fmt_ts(s['e'])}, {s['e']-s['s']:.1f}s) {s['text']}" for s in sents]
    mins = int(math.ceil(total_dur / 60))
    rate = [0] * mins
    for t in scenes:
        rate[min(mins - 1, int(t // 60))] += 1
    pacing = ", ".join(f"{m}:{rate[m]}" for m in range(mins))
    user = (f"Documentary file: {title_hint}\nDuration: {fmt_ts(total_dur)}\n"
            f"Scene changes per minute (minute:count): {pacing}\n\n"
            f"Transcript ({len(sents)} sentences):\n" + "\n".join(lines))
    if progress:
        progress(0.1)
    with client.beta.messages.stream(
        model=config.CLAUDE_MODEL,
        max_tokens=32000,
        system=_SYSTEM,
        messages=[{"role": "user", "content": user}],
        output_config={"effort": config.CLAUDE_EFFORT,
                       "format": {"type": "json_schema", "schema": _SCHEMA}},
        betas=["server-side-fallback-2026-07-01"],
        fallbacks="default",
    ) as stream:
        resp = stream.get_final_message()
    if resp.stop_reason == "refusal":
        raise RuntimeError("Claude declined to analyse this transcript.")
    if resp.stop_reason == "max_tokens":
        raise RuntimeError("Claude's answer was cut off (max_tokens).")
    text = next((b.text for b in resp.content if b.type == "text"), "")
    data = json.loads(text)
    usage = getattr(resp, "usage", None)
    data["_usage"] = {"input_tokens": getattr(usage, "input_tokens", None),
                      "output_tokens": getattr(usage, "output_tokens", None)}
    return data


def _snap_claude(sents, data) -> dict:
    """Validate Claude's answer against the real transcript. Never trust indices blindly."""
    n = len(sents)
    cands = data.get("candidates", [])
    cand_out = []
    for k, c in enumerate(cands):
        i, j = int(c["start_sentence"]), int(c["end_sentence"])
        if not (0 <= i < n and 0 <= j < n) or j < i:
            continue
        # Trim from the end until within the hard maximum.
        while j > i and sents[j]["e"] - sents[i]["s"] > SRC_MAX:
            j -= 1
        cand_out.append({"_k": k, "start_sentence": i, "end_sentence": j, "start": sents[i]["s"],
                         "end": sents[j]["e"], "title": c["working_title"],
                         "score": max(0, min(100, int(c["overall"]))), "selected": False,
                         "summary": c["assessment"],
                         "parts": {key: c[key] for key in ("storytelling", "historical_significance",
                                                           "curiosity", "pacing", "standalone_value")}})
    by_k = {c["_k"]: c for c in cand_out}
    clips = []
    for sel in data.get("selected", []):
        c = by_k.get(int(sel["candidate_index"]))
        if c is None or c["end"] - c["start"] < SRC_MIN - 3:
            continue
        clash = any(_overlap(c, x) > 0.15 for x in clips)
        if clash or len(clips) >= config.MAX_CLIPS:
            continue
        c["selected"] = True
        seg_text = " ".join(s["text"] for s in sents[c["start_sentence"]:c["end_sentence"] + 1]).lower()
        hl = [w for w in sel.get("highlight_words", []) if w and w.lower() in seg_text]
        tags = []
        for t in sel.get("hashtags", []):
            t = "#" + re.sub(r"[^A-Za-z0-9_]", "", t.lstrip("#"))
            if len(t) > 1 and t.lower() not in {x.lower() for x in tags}:
                tags.append(t)
        clips.append({"start_sentence": c["start_sentence"], "end_sentence": c["end_sentence"],
                      "start": c["start"], "end": c["end"], "title": sel["title"].strip()[:100],
                      "description": sel["description"].strip(), "hashtags": tags[:10],
                      "why_selected": sel["why_selected"].strip(), "keywords": hl,
                      "scores": c["parts"], "rank": None})
    cand_out.sort(key=lambda c: -c["score"])
    for r, c in enumerate(cand_out):
        c["rank"] = r + 1
        c.pop("_k", None)
    for cl in clips:
        cl["rank"] = next((c["rank"] for c in cand_out if c["start_sentence"] == cl["start_sentence"]
                           and c["end_sentence"] == cl["end_sentence"]), None)
    clips.sort(key=lambda x: x["start_sentence"])
    return {"candidates": cand_out, "clips": clips, "summary": data.get("documentary_summary", "")}


# --------------------------------------------------------------------------- entry point

def select_segments(transcript: dict, scenes: list[float], total_dur: float, title_hint: str,
                    progress: Optional[Callable[[float, str], None]] = None,
                    log: Callable[[str], None] = print) -> dict:
    sents = build_sentences(transcript["words"])
    mode = config.ANALYSIS_MODE
    use_claude = mode == "claude" or (mode == "auto" and bool(config.ANTHROPIC_API_KEY))
    result = None
    engine = "offline"
    if use_claude:
        try:
            if progress:
                progress(0.05, f"Claude ({config.CLAUDE_MODEL}) is reading the full transcript…")
            raw = claude_select(sents, scenes, total_dur, title_hint)
            result = _snap_claude(sents, raw)
            result["usage"] = raw.get("_usage")
            engine = "claude"
            if len(result["clips"]) < config.MIN_CLIPS:
                log(f"Claude returned {len(result['clips'])} usable clips; topping up with offline analysis.")
        except Exception as e:  # network, quota, bad key... fall back, but tell the user
            log(f"Claude analysis failed ({type(e).__name__}: {e}). Falling back to offline analysis.")
            result = None
    if result is None or len(result["clips"]) < config.MIN_CLIPS:
        if progress:
            progress(0.3, "Scoring every possible story window in the narration…")
        off = offline_select(sents, scenes, total_dur,
                             progress=(lambda f: progress(0.3 + 0.6 * f, "Scoring story windows…")) if progress else None)
        if result is None:
            result = off
        else:  # top up Claude's picks with non-overlapping offline picks
            for c in off["clips"]:
                if len(result["clips"]) >= config.MIN_CLIPS:
                    break
                cc = {**c, "start": sents[c["start_sentence"]]["s"], "end": sents[c["end_sentence"]]["e"]}
                if not any(_overlap(cc, x) > 0 for x in result["clips"]):
                    result["clips"].append(cc)
            result["clips"].sort(key=lambda x: x["start_sentence"])
            engine = "claude+offline"
    for c in result["clips"]:
        c["start"] = sents[c["start_sentence"]]["s"]
        c["end"] = sents[c["end_sentence"]]["e"]
        c["transcript"] = " ".join(s["text"] for s in sents[c["start_sentence"]:c["end_sentence"] + 1])
    result["engine"] = engine
    result["model"] = config.CLAUDE_MODEL if engine.startswith("claude") else "offline-storyscore-v1"
    result["sentence_count"] = len(sents)
    return result
